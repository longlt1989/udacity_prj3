import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node Step Trainer Trusted
StepTrainerTrusted_node1 = glueContext.create_dynamic_frame.from_catalog(
    database="longlt2-stedi-db",
    table_name="step_trainer_trusted",
    transformation_ctx="StepTrainerTrusted_node1",
)

# Script generated for node Accelerometer Landing
AccelerometerLanding_node1687792126205 = glueContext.create_dynamic_frame.from_catalog(
    database="longlt2-stedi-db",
    table_name="accelerometer_landing",
    transformation_ctx="AccelerometerLanding_node1687792126205",
)

# Script generated for node Join
Join_node1687792127908 = Join.apply(
    frame1=AccelerometerLanding_node1687792126205,
    frame2=StepTrainerTrusted_node1,
    keys1=["user"],
    keys2=["customername"],
    transformation_ctx="Join_node1687792127908",
)

# Script generated for node Drop Fields
DropFields_node1687792130727 = DropFields.apply(
    frame=Join_node1687792127908,
    paths=["customername"],
    transformation_ctx="DropFields_node1687792130727",
)

# Script generated for node Machine Learning Curated
MachineLearningCurated_node3 = glueContext.write_dynamic_frame.from_options(
    frame=DropFields_node1687792130727,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://longlt2-stedi/machine_learning/curated/",
        "partitionKeys": [],
    },
    transformation_ctx="MachineLearningCurated_node3",
)

job.commit()
