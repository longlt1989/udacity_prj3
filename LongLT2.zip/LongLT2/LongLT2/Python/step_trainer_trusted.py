import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node Customer Curated
CustomerCurated_node1687775406490 = glueContext.create_dynamic_frame.from_catalog(
    database="longlt2-stedi-db",
    table_name="customer_curated",
    transformation_ctx="CustomerCurated_node1687775406490",
)

# Script generated for node Step Trainer Landing
StepTrainerLanding_node1 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": False},
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://longlt2-stedi/step_trainer/landing/"],
        "recurse": True,
    },
    transformation_ctx="StepTrainerLanding_node1",
)

# Script generated for node Join
Join_node1687775411559 = Join.apply(
    frame1=StepTrainerLanding_node1,
    frame2=CustomerCurated_node1687775406490,
    keys1=["serialNumber"],
    keys2=["serialnumber"],
    transformation_ctx="Join_node1687775411559",
)

# Script generated for node Drop Fields
DropFields_node1687775417613 = DropFields.apply(
    frame=Join_node1687775411559,
    paths=[
        "email",
        "lastupdatedate",
        "sharewithresearchasofdate",
        "sharewithfriendsasofdate",
        "sharewithpublicasofdate",
        "birthdate",
        "phone",
        "serialnumber",
        "registrationdate",
    ],
    transformation_ctx="DropFields_node1687775417613",
)

# Script generated for node Step Trainer Trusted
StepTrainerTrusted_node3 = glueContext.write_dynamic_frame.from_options(
    frame=DropFields_node1687775417613,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://longlt2-stedi/step_trainer/trusted/",
        "partitionKeys": [],
    },
    transformation_ctx="StepTrainerTrusted_node3",
)

job.commit()
